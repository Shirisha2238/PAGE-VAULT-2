const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "pagevault.db"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS books (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 owner_id INTEGER NOT NULL REFERENCES users(id),
 title TEXT NOT NULL,
 author TEXT NOT NULL,
 subject TEXT NOT NULL,
 condition TEXT NOT NULL,
 description TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'available'
   CHECK(status IN ('available','requested','borrowed')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS borrow_requests (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 book_id INTEGER NOT NULL REFERENCES books(id),
 borrower_id INTEGER NOT NULL REFERENCES users(id),
 owner_id INTEGER NOT NULL REFERENCES users(id),
 status TEXT NOT NULL DEFAULT 'pending'
   CHECK(status IN ('pending','approved','rejected','returned')),
 requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 due_date TEXT,
 returned_at TEXT
);
`);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000 * 60 * 60 * 8 }
}));
app.use("/api", rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

const clean = (v, max = 120) => typeof v === "string" ? v.trim().slice(0, max) : "";
const emailOk = v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const currentUser = req => req.session.user || null;
function requireAuth(req, res, next) {
  if (!currentUser(req)) return res.status(401).json({ error: "Please sign in first." });
  next();
}
function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
function safeBook(row) {
  return { id: row.id, title: row.title, author: row.author, subject: row.subject,
    condition: row.condition, description: row.description, status: row.status,
    ownerName: row.owner_name, ownerId: row.owner_id, createdAt: row.created_at };
}

app.post("/api/register", async (req, res) => {
  const name = clean(req.body.name, 60), email = clean(req.body.email, 120).toLowerCase();
  const password = typeof req.body.password === "string" ? req.body.password : "";
  if (name.length < 2 || !emailOk(email) || password.length < 8)
    return res.status(400).json({ error: "Enter a name, valid email, and password of at least 8 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)").run(name,email,hash);
    req.session.user = { id: Number(result.lastInsertRowid), name, email };
    res.status(201).json({ user: req.session.user });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "That email is already registered." });
    res.status(500).json({ error: "Could not create account." });
  }
});
app.post("/api/login", async (req, res) => {
  const email = clean(req.body.email,120).toLowerCase(), password = typeof req.body.password === "string" ? req.body.password : "";
  const user = db.prepare("SELECT * FROM users WHERE email=?").get(email);
  if (!user || !(await bcrypt.compare(password,user.password_hash))) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.user = { id:user.id, name:user.name, email:user.email };
  res.json({ user:req.session.user });
});
app.post("/api/logout", (req,res) => req.session.destroy(() => res.json({ ok:true })));
app.get("/api/me", (req,res) => res.json({ user:currentUser(req) }));

app.get("/api/books", (req,res) => {
  const q = clean(req.query.q,100), subject = clean(req.query.subject,60);
  let sql = `SELECT b.*,u.name owner_name FROM books b JOIN users u ON u.id=b.owner_id WHERE 1=1`;
  const args = [];
  if (q) { sql += " AND (b.title LIKE ? OR b.author LIKE ? OR b.subject LIKE ?)"; args.push(`%${q}%`,`%${q}%`,`%${q}%`); }
  if (subject) { sql += " AND b.subject=?"; args.push(subject); }
  sql += " ORDER BY b.created_at DESC";
  res.json({ books:db.prepare(sql).all(...args).map(safeBook) });
});
app.post("/api/books", requireAuth, (req,res) => {
  const title=clean(req.body.title,120), author=clean(req.body.author,100), subject=clean(req.body.subject,60);
  const condition=clean(req.body.condition,30), description=clean(req.body.description,500);
  if (!title || !author || !subject || !["New","Good","Used"].includes(condition))
    return res.status(400).json({ error:"Title, author, subject and a valid condition are required." });
  const r=db.prepare("INSERT INTO books(owner_id,title,author,subject,condition,description) VALUES(?,?,?,?,?,?)")
    .run(currentUser(req).id,title,author,subject,condition,description);
  res.status(201).json({ id:Number(r.lastInsertRowid) });
});

app.post("/api/books/:id/request", requireAuth, (req,res) => {
  const book=db.prepare("SELECT * FROM books WHERE id=?").get(Number(req.params.id));
  if (!book) return res.status(404).json({error:"Book not found."});
  const user=currentUser(req);
  if (book.owner_id===user.id) return res.status(400).json({error:"You cannot request your own book."});
  if (book.status!=="available") return res.status(409).json({error:"This book is not currently available."});
  const exists=db.prepare("SELECT id FROM borrow_requests WHERE book_id=? AND borrower_id=? AND status IN ('pending','approved')").get(book.id,user.id);
  if (exists) return res.status(409).json({error:"You already have an active request for this book."});
  const result=db.prepare("INSERT INTO borrow_requests(book_id,borrower_id,owner_id) VALUES(?,?,?)").run(book.id,user.id,book.owner_id);
  db.prepare("UPDATE books SET status='requested' WHERE id=?").run(book.id);
  res.status(201).json({id:Number(result.lastInsertRowid)});
});
app.get("/api/dashboard", requireAuth, (req,res) => {
  const id=currentUser(req).id;
  const requests=db.prepare(`SELECT r.*,b.title,b.author,bu.name borrower_name,ou.name owner_name
    FROM borrow_requests r JOIN books b ON b.id=r.book_id
    JOIN users bu ON bu.id=r.borrower_id JOIN users ou ON ou.id=r.owner_id
    WHERE r.owner_id=? OR r.borrower_id=? ORDER BY r.requested_at DESC`).all(id,id);
  const myBooks=db.prepare("SELECT * FROM books WHERE owner_id=? ORDER BY created_at DESC").all(id);
  res.json({requests,myBooks});
});
app.post("/api/requests/:id/decision", requireAuth, (req,res) => {
  const request=db.prepare("SELECT * FROM borrow_requests WHERE id=?").get(Number(req.params.id));
  if (!request) return res.status(404).json({error:"Request not found."});
  if (request.owner_id!==currentUser(req).id) return res.status(403).json({error:"Only the book owner can decide this request."});
  if (request.status!=="pending") return res.status(409).json({error:"This request has already been processed."});
  const decision=req.body.decision;
  if (!["approve","reject"].includes(decision)) return res.status(400).json({error:"Choose approve or reject."});
  const transaction=db.transaction(() => {
    if (decision==="approve") {
      const due=addDays(new Date(),14);
      db.prepare("UPDATE borrow_requests SET status='approved',due_date=? WHERE id=?").run(due,request.id);
      db.prepare("UPDATE books SET status='borrowed' WHERE id=?").run(request.book_id);
    } else {
      db.prepare("UPDATE borrow_requests SET status='rejected' WHERE id=?").run(request.id);
      db.prepare("UPDATE books SET status='available' WHERE id=?").run(request.book_id);
    }
  });
  transaction(); res.json({ok:true});
});
app.post("/api/requests/:id/return", requireAuth, (req,res) => {
  const r=db.prepare("SELECT * FROM borrow_requests WHERE id=?").get(Number(req.params.id));
  if (!r) return res.status(404).json({error:"Request not found."});
  if (r.borrower_id!==currentUser(req).id && r.owner_id!==currentUser(req).id)
    return res.status(403).json({error:"You are not part of this borrowing transaction."});
  if (r.status!=="approved") return res.status(409).json({error:"Only an approved loan can be marked returned."});
  const transaction=db.transaction(() => {
    db.prepare("UPDATE borrow_requests SET status='returned',returned_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);
    db.prepare("UPDATE books SET status='available' WHERE id=?").run(r.book_id);
  });
  transaction(); res.json({ok:true});
});

app.get("*", (req,res) => res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT, () => console.log(`PageVault running at http://localhost:${PORT}`));
