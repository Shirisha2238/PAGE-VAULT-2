# PageVault – OpenShelf Challenge (Improved Version)

This package upgrades the original static source directory into a basic peer-to-peer textbook exchange application.

## Implemented features

- Student registration and sign-in with hashed passwords.
- Book listing form with title, author, subject, condition and description.
- Search by title, author or subject, plus subject filter.
- Borrow request workflow: request, owner approval/rejection, and return.
- Automatic 14-day due date when a request is approved.
- Management Hub showing requests and loan status.
- SQLite persistence for users, books and requests.
- Server-side validation, parameterized SQL, session cookies, Helmet security headers and API rate limiting.
- Automated due-date tests.

## Technology

- Frontend: HTML, CSS, JavaScript
- Backend: Node.js + Express
- Database: SQLite (`better-sqlite3`)

## Requirements

Install Node.js 20 or later.

## Run locally

1. Extract the ZIP file.
2. Open the extracted `PageVault_Improved` folder in VS Code.
3. Open Terminal in that folder.
4. Run:

   ```bash
   npm install
   ```

5. Copy `.env.example` to `.env` and set a long random `SESSION_SECRET`.
6. Start the app:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in your browser.
8. Register two test accounts in separate browsers/profiles. List a book with one account, then request it using the other account. Approve it from the owner's Management Hub and test the return action.

## Run tests

```bash
npm test
```

## Evaluation feedback addressed

| Evaluation report issue | Improvement in this version |
|---|---|
| No book listing form | Added authenticated book listing |
| No borrow request workflow | Added request, approve, reject and return |
| No due-date calculation | Sets a 14-day due date on approval |
| No Management Hub | Added dashboard for incoming/outgoing requests |
| Static hardcoded data | Books and requests are stored in SQLite |
| No authentication | Registration, login, logout and sessions |
| No input validation | Client and server-side validation |
| Single static page only | Separated server, frontend and tests |
| No automated business-logic test | Added due-date tests |

## Important notes

- This is a student project starter, not a production-ready lending service.
- For deployment, configure HTTPS, a strong secret, a persistent session store, database backups, CSRF protection and account recovery.
- The due-date rule is currently fixed at 14 days because the evaluation feedback asks for due-date calculation but does not specify a different loan period.
- The original uploaded `index.html` is preserved as `original-index.html` for comparison.
