const test = require("node:test");
const assert = require("node:assert/strict");
function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
test("due date is 14 days after approval date", () => {
  assert.equal(addDays("2026-01-01", 14), "2026-01-15");
});
test("due date handles month boundary", () => {
  assert.equal(addDays("2026-01-25", 14), "2026-02-08");
});